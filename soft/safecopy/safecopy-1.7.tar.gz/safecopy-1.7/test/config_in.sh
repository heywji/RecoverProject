#!/bin/false

safecopy="$testsuite_basedir/src/safecopy"

debuglib="$testsuite_basedir/simulator/src/libsimulatorlb.so.1.0"

preload="$debuglib: $LD_PRELOAD"



