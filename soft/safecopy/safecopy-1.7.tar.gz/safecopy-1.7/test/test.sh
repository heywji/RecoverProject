#!/bin/bash

source "libtestsuite.sh"

testsuite_runall

