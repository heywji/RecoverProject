# -*- coding: utf-8 -*-


class RequestException(Exception):
    pass
