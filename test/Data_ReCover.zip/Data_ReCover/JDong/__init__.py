# -*- coding: utf-8 -*-

__title__ = 'JDong'

__version__ = '0.0.1'
# 第一位大版本号，大功能发布时增加，技术负责人审核；
# 第二位小版本号，增加小特性时增加，主开发审核；
# 第三位BUG修复号，修复BUG用，修复人员负责

__author__ = 'Chyroc Chen'

from .api import JDong

__all__ = ['JDong']
